add = 0
for i in range(1, 11):
	add = add + i
print(add)

